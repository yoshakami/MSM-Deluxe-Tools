#wait for msm deluxe v2
import os
print("bro that's cheating")
os.system('pause')